---
id: vue-image-gallery
title: Image Gallery for Vue.js
sidebar_label: for Vue
---

Here's an example on how to use PhotoSwipe with Vue to create a simple image gallery. [Browse and edit code on Stackblitz](https://stackblitz.com/edit/vue-hatnqg).

<iframe src="https://stackblitz.com/edit/vue-hatnqg?embed=1&file=src/SimpleGallery.vue&hideNavigation=1"></iframe>

There is no special component specifically for Vue yet, if you developed one (for v5) - please let me know and I'll link it here.

   
   
